/*
IDA* double ended search with pruning tables to find optimal solution for rubiks cube.
*/
#include <iostream>
#include <array>
#include <vector>

#include "./CubeState.h"
#include "./CornerPatternDB.h"

using namespace std;

int main()
{
    CubeState cube;

    // Testing

    cube.display();
    cube.solvedState();

    cube.r();
    cube.l3();
    cube.u();

    cube.display();
    cube.solvedState();

    return 0;
}

